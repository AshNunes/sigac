<?php echo phpinfo(); ?>

