@extends('templates/main', ['titulo'=>"HOME"])

@section('conteudo')

<span class="fs-4"->Seja bem-vindo(a)<br>Gil Eduardo de Andrade</span>

@endsection

