@extends('templates/site')

@section('conteudo')

    <div class="mt-5 text-center">
        <img src="{{asset('img/ifpr.png')}}" width="256px" height="256px">
        <br><br>
        <span class="fw-light text-success fs-3 mb-3">
            Sistema de Gerenciamento de Atividades Complementares
        </span>
    </div>

@endsection
